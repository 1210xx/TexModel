for k = 1:5
    disp(k);
end