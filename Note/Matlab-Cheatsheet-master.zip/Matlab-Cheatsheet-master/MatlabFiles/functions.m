function output = addNumbers(x, y)
    output = x + y;
end

addNumbers(10, -5)
    5