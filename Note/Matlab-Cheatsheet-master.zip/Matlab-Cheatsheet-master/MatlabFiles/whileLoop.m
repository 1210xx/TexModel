k = 0;
while k < 7
    k = k + 1;
end