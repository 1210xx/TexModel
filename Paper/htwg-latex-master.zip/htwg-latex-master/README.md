# HTWG Corporate Identity LaTeX Template for Reports and Theses

> Based on _tudelft-report-latex_
> 
> see: [GitHub: tudelft-report-latex @ 4983bea](https://github.com/praseodym/tudelft-report-latex/tree/4983bea3e88ae9010bc25576f36ebefed3257228)

## HTWG Corporate Design

see: [HTWG Konstanz Corporate-Design-Logo](https://www.htwg-konstanz.de/hochschule/einrichtungen/stabsstelle-kommunikation/corporate-design-logo/)

