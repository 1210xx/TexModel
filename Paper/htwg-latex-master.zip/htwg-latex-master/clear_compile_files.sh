#!/bin/sh
rm -rf *.aux *.bbl *.blg *.log *.out *.bak *.dvi *.lof *.lol *.lot *.toc *.synctex.gz preface\*.aux
