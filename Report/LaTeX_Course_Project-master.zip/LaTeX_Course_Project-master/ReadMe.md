# 介绍
这是合肥工业大学的课程设计模板，仿照官方给的word模板制作的。封面显示效果与原word模板基本一致，此项目里包含有word模板和LaTeX模板。
# 使用
下载解压之后就可以直接使用了,也可以在此模板的基础上编辑成自己需要的样子。
# 我的使用环境
win 10 64bits

TexLive

Texstudio

pdfLaTeX编译
# 联系我
使用过程中有什么问题也可以发邮件联系我。

Email：jiayuhang@mail.hfut.edu.cn
